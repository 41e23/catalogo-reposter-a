# Guía – Parte de Matías (Evaluación 2 Backend)
App: `materiales` | Modelo: `Material` | Form: `MaterialForm`

## 1. Archivos de esta entrega
| Archivo | Destino en el proyecto |
|---|---|
| models.py | materiales/models.py |
| forms.py | materiales/forms.py |
| admin.py | materiales/admin.py |
| migrations/0001_initial.py | materiales/migrations/0001_initial.py |

> Si tu versión de Django es distinta a la de la migración, borra `0001_initial.py`
> y genera la tuya con `python manage.py makemigrations materiales`.

## 2. Migraciones (con .venv activada y PostgreSQL de Pablo funcionando)
```powershell
.venv\Scripts\Activate.ps1
python manage.py check
python manage.py makemigrations materiales
python manage.py migrate
python manage.py showmigrations materiales
```
Capturas: terminal + archivo de migración.

## 3. Superusuario y Admin
```powershell
python manage.py createsuperuser
python manage.py runserver
```
Entrar a http://127.0.0.1:8000/admin/ y hacer (una captura cada punto):
1. Crear 3 materiales (ej: Harina 0000 $1.200 / Chocolate cobertura $4.500 / Moldes de silicona $6.990).
2. Modificar uno (ej: chocolate a $4.990) → captura antes y después.
3. Eliminar uno → captura.
4. Mostrar filtros (lateral derecho) y buscador funcionando.
5. Validación: intentar guardar un material con precio 50 o nombre "Ha" → el Admin muestra el error (el Admin usa `MaterialForm`).

## 4. Verificar en pgAdmin (solo mirar, no editar)
Servers > tu BD > Schemas > public > Tables > **materiales_material** > View/Edit Data > All Rows.
Captura con la tabla y los registros.

## 5. Capturas a juntar
- [ ] models.py
- [ ] Migración 0001_initial.py + comandos ejecutados
- [ ] Admin: modelo registrado y listado con columnas, filtros y buscador
- [ ] 3 registros creados
- [ ] 1 registro modificado (antes/después)
- [ ] 1 registro eliminado
- [ ] Validación funcionando (error de precio/nombre)
- [ ] pgAdmin con tabla y registros

## 6. Commits sugeridos (con tu usuario de Git)
```powershell
git checkout -b feature/materiales-modelo
git add materiales/models.py materiales/migrations/
git commit -m "Agrega modelo Material y migración inicial"
git add materiales/forms.py
git commit -m "Agrega MaterialForm con validación de precio mínimo y nombre"
git add materiales/admin.py
git commit -m "Registra Material en Admin con filtros, buscador y validación"
git push origin feature/materiales-modelo
```

## 7. Registro de IA (para el informe)
| Campo | Qué escribir |
|---|---|
| Problema | Crear modelo, ModelForm y Admin para Material en `materiales/` |
| Prompt | (pega aquí el prompt real que usaste) |
| Respuesta | Código de models.py, forms.py, admin.py |
| Decisión | Qué aceptaste/cambiaste (precio mínimo, categorías, verbose_name con tildes) |
| Verificación | check/makemigrations/migrate sin errores; 3 registros en Admin y pgAdmin; errores de validación visibles |
| Reflexión | Qué aprendiste (ModelForm, clean_<campo>, list_filter, auto_now_add) |

## 8. Qué debes poder explicar si te preguntan
- Por qué `fecha_registro` no está en el formulario (la controla el sistema con `auto_now_add`).
- Qué hace `clean_precio` / `clean_nombre` y cuándo Django los ejecuta.
- Qué hacen `list_display`, `list_filter`, `search_fields` y `form = MaterialForm` en el Admin.
- Por qué `categoria` usa `choices`.
