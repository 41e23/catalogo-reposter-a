# Verificación contra las dos hojas (División de trabajo + Rúbrica Evaluación 2)

## A. Tareas de Matías (hoja "División de trabajo")
| Tarea | Estado |
|---|---|
| Trabajar en la app `materiales` | ✅ |
| Modelo Material en models.py | ✅ |
| Mínimo: nombre, categoría, precio, disponibilidad, descripción | ✅ (+ fecha_registro) |
| Crear migraciones | ✅ archivo incluido (regenerar si tu Django difiere) |
| Ejecutar y comprobar migraciones | ⏳ tú, en tu PostgreSQL |
| materiales/forms.py + ModelForm | ✅ |
| Validación propia (precio mínimo) | ✅ precio ≥ $100 y nombre válido |
| Registrar Material en Admin | ✅ |
| Admin muestra nombre, categoría, precio, disponibilidad | ✅ |
| Filtros y buscador en Admin | ✅ |
| Crear superusuario | ⏳ tú |
| 3 registros desde /admin/ | ⏳ tú |
| Modificar y eliminar desde Admin | ⏳ tú |
| Verificar en pgAdmin | ⏳ tú (tabla `materiales_material`) |
| Capturas (models, migración, Admin, registros, validación) | ⏳ tú |
| Commits propios en GitHub | ⏳ tú |

## B. Rúbrica (100 pts) – parte que aporta Matías
| Criterio | Pts | Aporte de Matías | Estado |
|---|---|---|---|
| PostgreSQL y .env | 15 | Verificación en pgAdmin (config es de Pablo) | ⏳ evidencia |
| Modelos y migraciones | 15 | Modelo pertinente + migración aplicada + evidencia | ✅ código / ⏳ evidencia |
| Django Admin | 10 | Superusuario, modelo registrado, registros gestionados | ✅ código / ⏳ evidencia |
| CRUD desde HTML | 30 | `MaterialForm` para el CRUD de Álvaro | ✅ tu parte |
| Validación y seguridad | 15 | Campos obligatorios + regla propia; no hay secretos en tus archivos | ✅ |
| GitHub y equipo | 10 | Commits identificables | ⏳ |
| IA y reflexión | 5 | Registro de IA llenado con datos reales | ⏳ |

## C. Condiciones generales de la hoja de Evaluación 2
| Condición | Estado |
|---|---|
| Entidad conectada con la problemática (materiales de repostería) | ✅ |
| Datos gestionados desde Django; pgAdmin solo para verificar | ✅ (la guía lo respeta) |
| No se publican contraseñas ni .env | ✅ ningún archivo de Matías contiene secretos |
| Evidencia: models.py, migración, comandos, pgAdmin, Admin | ⏳ capturas |

## D. Pruebas realizadas sobre el código (proyecto de prueba, SQLite)
- `manage.py check` sin errores y `makemigrations --check` sin cambios pendientes.
- Admin: crear 3 materiales, editar, eliminar, buscar, filtrar por categoría → OK.
- Validación: precio 50 → rechazado; nombre "Ha" → rechazado; campos vacíos → rechazados; datos válidos → aceptados.
- No probado: PostgreSQL real (hacerlo en tu entorno).
