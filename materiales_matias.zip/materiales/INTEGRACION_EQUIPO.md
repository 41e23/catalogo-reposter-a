# Integración – lo que Pablo y Álvaro necesitan saber de la parte de Matías

## Nombres exactos (no cambiar)
- App: `materiales`
- Modelo: `Material` → campos: `nombre`, `categoria`, `precio`, `disponible`, `descripcion`, `fecha_registro` (automático)
- Formulario: `MaterialForm` en `materiales/forms.py` → campos editables: nombre, categoria, precio, disponible, descripcion
- Tabla en PostgreSQL: `materiales_material`

## Para Álvaro (vistas / templates)
```python
from .models import Material
from .forms import MaterialForm
```
- Listar: `Material.objects.all()` (ya viene ordenado por nombre).
- Crear/editar: usar `MaterialForm` (y `MaterialForm(instance=obj)` para editar).
- Mostrar errores en el template: `{{ form.nombre.errors }}`, `{{ form.precio.errors }}` o `{{ form.errors }}`.
- Mostrar categoría legible: `{{ m.get_categoria_display }}`.
- Reglas de validación ya incluidas: precio mínimo $100, nombre mínimo 3 caracteres y no solo números, campos obligatorios.

## Para Pablo (PostgreSQL / integración)
- Necesita PostgreSQL funcionando en `config/settings.py` ANTES de que Matías ejecute `migrate`.
- `materiales` debe estar en `INSTALLED_APPS`.
- La portada puede usar `Material.objects.filter(disponible=True)[:6]`.
- Orden sugerido de merge: Pablo (config) → Matías (modelo) → Álvaro (CRUD).
